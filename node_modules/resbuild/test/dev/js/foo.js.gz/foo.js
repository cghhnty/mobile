document.body.innerHTML += "foo.js loaded<br>";
//# sourceMappingURL=foo.js.map