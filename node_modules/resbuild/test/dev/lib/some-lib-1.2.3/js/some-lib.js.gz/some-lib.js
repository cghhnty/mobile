document.body.innerHTML += "some-lib.js loaded<br>";
//# sourceMappingURL=some-lib.js.map